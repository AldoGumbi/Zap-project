-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 22-04-2023 a las 04:10:08
-- Versión del servidor: 10.4.27-MariaDB
-- Versión de PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `zapateria`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carrito_cliente`
--

CREATE TABLE `carrito_cliente` (
  `Pedido` int(11) NOT NULL,
  `Id_Producto` int(11) DEFAULT NULL,
  `Cantidad` int(11) NOT NULL,
  `Precio_Producto` double(6,2) NOT NULL,
  `Importe` double(10,2) GENERATED ALWAYS AS (`Precio_Producto` * `Cantidad`) VIRTUAL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `carrito_cliente`
--

INSERT INTO `carrito_cliente` (`Pedido`, `Id_Producto`, `Cantidad`, `Precio_Producto`) VALUES
(1000002181, 300033494, 2, 1450.00),
(1000002181, 300030011, 1, 1799.00),
(1000002185, 300030028, 1, 2199.00),
(1000002187, 300030028, 1, 2199.00),
(1000002188, 300030020, 1, 2199.00),
(1000002188, 300030019, 1, 1799.00),
(1000002188, 300033502, 1, 1450.00),
(1000002191, 300030004, 9, 1890.00),
(1000002191, 300030020, 9, 2199.00),
(1000002193, 300030017, 9, 1799.00),
(1000002194, 300030015, 9, 1799.00),
(1000002194, 300030028, 1, 2199.00);

--
-- Disparadores `carrito_cliente`
--
DELIMITER $$
CREATE TRIGGER `total_pedido` AFTER UPDATE ON `carrito_cliente` FOR EACH ROW BEGIN
set @id_pedido=OLD.Pedido;
UPDATE pedido_cliente SET Total=(SELECT SUM(Importe) FROM carrito_cliente WHERE Pedido=@id_pedido) where Id_PC=@id_pedido;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `total_pedido_delete` AFTER DELETE ON `carrito_cliente` FOR EACH ROW BEGIN
set @id_pedido=OLD.Pedido;
UPDATE pedido_cliente SET Total=(SELECT SUM(Importe) 
FROM carrito_cliente WHERE Pedido=@id_pedido) where Id_PC=@id_pedido;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `Id_Cliente` int(11) NOT NULL,
  `Nombre` varchar(150) NOT NULL,
  `ApellidoP` varchar(50) NOT NULL,
  `ApellidoM` varchar(50) NOT NULL,
  `Domicilio` varchar(150) NOT NULL,
  `Ciudad` varchar(100) NOT NULL,
  `Estado` varchar(50) NOT NULL,
  `Telefono` bigint(20) NOT NULL,
  `Saldo` int(11) NOT NULL,
  `Correo` varchar(150) NOT NULL,
  `Contrasenia` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`Id_Cliente`, `Nombre`, `ApellidoP`, `ApellidoM`, `Domicilio`, `Ciudad`, `Estado`, `Telefono`, `Saldo`, `Correo`, `Contrasenia`) VALUES
(10000888, 'Pepe', 'Pascal', 'Villanueva', 'Enrique Diaz #2444', 'Tlaquepaque', 'Jalisco', 332011279, 1200, 'Pedro_01@hotmail.com', 'Pedro1234'),
(10000889, 'Juan', 'García', 'Sánchez', 'Av. Juárez 123', 'Monterrey', 'Nuevo León', 8123456789, 1001, 'Juan_01@hotmail.com', 'Juan1234'),
(10000890, 'María', 'González', 'Hernández', 'Calle Reforma 456', 'Guadalajara', 'Jalisco', 3335556789, 500, 'Maria_01@gmail.com', 'Maria1234'),
(10000891, 'Pedro', 'Martínez', 'Gómez', 'Blvd. Adolfo López Mateos 789', 'México DF', 'Ciudad de México', 5554321098, 1500, 'Pedro_01@mail.com', 'Pedro1234'),
(10000892, 'Ana', 'Ramírez', 'Pérez', 'Calle 5 de Mayo 234', 'Puebla', 'Puebla', 2228765432, 751, 'Ana_01@hotmail.com', 'Ana12345'),
(10000893, 'Miguel', 'Sánchez', 'López', 'Av. Reforma 876', 'Tijuana', 'Baja California', 6642345678, 2000, 'Miguel_01@gmail.com', 'Miguel1234'),
(10000894, 'Laura', 'Hernández', 'Guzmán', 'Calle Hidalgo 345', 'Morelia', 'Michoacán', 4439876543, 101, 'Laura_01@hotmail.com', 'Laura1234'),
(10000895, 'Ricardo', 'Pérez', 'Castillo', 'Av. López Portillo 789', 'Cancún', 'Quintana Roo', 9987654321, 3500, 'Ricardo_01@gmail.com', 'Ricardo1234'),
(10000929, 'Daniel Alejandro ', 'Ramiez', 'Lopez', 'Pablo Neruda #200 Providencia', 'Guadalajara', 'Jalisco', 4433789956, 0, 'Daniel_01@hotmail.com', 'Daniel1234');

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `cliente_pedido`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `cliente_pedido` (
`Id_PC` int(11)
,`Nombre` varchar(150)
,`ApellidoP` varchar(50)
,`ApellidoM` varchar(50)
,`Fecha_Pedido` timestamp
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamento`
--

CREATE TABLE `departamento` (
  `Id_Departamento` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `departamento`
--

INSERT INTO `departamento` (`Id_Departamento`, `Nombre`) VALUES
(10, 'Administracion'),
(20, 'Almacen'),
(30, 'Inventarios'),
(40, 'Recursos Humanos'),
(50, 'E-Commerce'),
(60, 'Piso de Venta');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado`
--

CREATE TABLE `empleado` (
  `Id_Empleado` int(11) NOT NULL,
  `Nombre` varchar(150) NOT NULL,
  `ApellidoP` varchar(50) NOT NULL,
  `ApellidoM` varchar(50) NOT NULL,
  `Domicilio` varchar(150) NOT NULL,
  `Ciudad` varchar(100) NOT NULL,
  `Estado` varchar(50) NOT NULL,
  `Telefono` bigint(20) NOT NULL,
  `Numero_Seguro` int(11) NOT NULL,
  `RFC` varchar(15) NOT NULL,
  `Puesto` varchar(50) NOT NULL,
  `Correo` varchar(150) NOT NULL,
  `Contrasenia` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `empleado`
--

INSERT INTO `empleado` (`Id_Empleado`, `Nombre`, `ApellidoP`, `ApellidoM`, `Domicilio`, `Ciudad`, `Estado`, `Telefono`, `Numero_Seguro`, `RFC`, `Puesto`, `Correo`, `Contrasenia`) VALUES
(1, 'Administrador', '', '', '', '', '', 0, 0, '', '', '', 'admin@2023'),
(29, 'David ', 'Avila', 'Gutierrez', 'Frambuesos #3000', 'Zapopan', 'Jalisco', 3340409087, 1400002345, 'DAXG020302123', '14', 'David_01@gmail.com', 'David1234'),
(30, 'Laura Esther', 'Padilla', 'Vazquez', 'Nueva consti #3434', 'Las Lomas', 'Ciudad de Mexico', 8909090965, 1423000023, 'LPEV6005678', '13', 'Laura_01@hotmail.com', 'Laura1234'),
(31, 'Cinthya', 'Rodriguez', 'Gonzalez', 'La paz #4560', 'Polanco', 'Ciudad de Mexico', 3389000012, 142323789, 'CRXG900800', '22', 'Cinthya_01@gmail.com', 'Cinthya1234'),
(32, 'Chris Alberto', 'Sanchez', 'Davila', 'Revolucion #4580', 'Monterrey', 'Nuevo Leon', 2323002323, 148909890, 'CSAD890967', '33', 'Chris_01@hotmail.com', 'Chris1234'),
(33, 'Alejandro', 'Segoviano', 'Hernandez', 'Las piñatas #3280', 'Zapopan', 'Jalisco', 3320302303, 1467777899, 'ASXH543677', '41', 'Alejandro_01@gmail.com', 'Alejandro1234'),
(34, 'Abraham Carlos', 'Perez', 'Rodriguez', 'Revolucion #1212', 'Polanco', 'Ciudad de Mexico', 3366666666, 142008904, 'APCR9090677', '52', 'Abraham_01@hotmail.com', 'Abraham1234'),
(35, 'Luis Fernando', 'Montiel', 'Sanchez', 'Las pintas #56', 'Zapopan', 'Jalisco', 3300110020, 12300089, 'LSFS09090912', '61', 'Luis_02@hotmail.com', 'Luis1234'),
(36, 'David Armando', 'Flores', 'Garcia', 'Frambuesos #4500', 'Zapopan', 'Jalisco', 3340119087, 1400002345, 'DFAG020302123', '14', 'David_02@gmail.com', 'David1234'),
(37, 'Laura Alejandra', 'Gonzalez', 'Magaña', 'Nueva consti #3490', 'Las Lomas', 'Ciudad de Mexico', 8909110965, 1423000023, 'LGAM6005678', '21', 'Laura_02@hotmail.com', 'Laura1234');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedido_cliente`
--

CREATE TABLE `pedido_cliente` (
  `Id_PC` int(11) NOT NULL,
  `Fecha_Pedido` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Fecha_Entrega` date NOT NULL,
  `Metodo_Entrega` varchar(100) DEFAULT NULL,
  `Metodo_Pago` varchar(100) DEFAULT NULL,
  `Total` double(15,2) NOT NULL,
  `Id_Cliente` int(11) DEFAULT NULL,
  `Atendio` varchar(11) DEFAULT NULL,
  `Estatus` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pedido_cliente`
--

INSERT INTO `pedido_cliente` (`Id_PC`, `Fecha_Pedido`, `Fecha_Entrega`, `Metodo_Entrega`, `Metodo_Pago`, `Total`, `Id_Cliente`, `Atendio`, `Estatus`) VALUES
(1000002181, '2023-04-17 11:03:19', '2023-04-06', 'Domicilio', 'Debito', 4699.00, 10000888, '3', 'Completado'),
(1000002182, '2023-04-17 10:50:59', '2019-03-24', NULL, NULL, 0.00, 10000888, '33', 'completado'),
(1000002185, '2023-04-18 10:26:09', '0000-00-00', 'Metodo de entrega', 'Metodo Pago', 3998.00, 10000888, '3', 'Completado'),
(1000002187, '2023-04-17 10:43:48', '2023-04-18', 'Metodo de entrega', 'Metodo Pago', 3998.00, 10000894, '1', ''),
(1000002188, '2023-04-17 10:43:48', '2023-05-03', 'Metodo de entrega', 'Metodo Pago', 5448.00, 10000894, '1', ''),
(1000002191, '2023-04-18 07:23:23', '2023-04-26', 'Recoger', 'Debito', 36801.00, 10000894, NULL, ''),
(1000002193, '2023-04-18 10:34:25', '0000-00-00', NULL, NULL, 16191.00, 10000888, NULL, ''),
(1000002194, '2023-04-21 01:16:07', '2023-04-28', 'Domicilio', 'Credito', 18390.00, 10000929, '3', 'Completado');

--
-- Disparadores `pedido_cliente`
--
DELIMITER $$
CREATE TRIGGER `pedido_completado_trigger` BEFORE UPDATE ON `pedido_cliente` FOR EACH ROW BEGIN
set @id_pedido=OLD.Id_PC;
set @fecha=OLD.Fecha_entrega;
set @entrega=OLD.Metodo_Entrega;
set @cliente=OLD.Id_Cliente;
if OLD.Estatus = 'Completado'
	THEN
      INSERT INTO pedido_com (Id_PC,Fecha_Entrega, Metodo_Entrega, Id_Cliente) values(@id_pedido,@fecha,@entrega,@cliente);
  END IF;

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `pedido_com`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `pedido_com` (
`Id_PC` int(11)
,`Fecha_Entrega` date
,`Metodo_Entrega` varchar(100)
,`Id_Cliente` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `pedido_producto`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `pedido_producto` (
`Pedido` int(11)
,`Modelo` varchar(10)
,`Descripcion` varchar(100)
,`Talla` double(3,1)
,`color` varchar(50)
,`Cantidad` int(11)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `Id_Producto` int(11) NOT NULL,
  `Modelo` varchar(10) NOT NULL,
  `Marca` varchar(50) NOT NULL,
  `Descripcion` varchar(100) NOT NULL,
  `Talla` double(3,1) NOT NULL,
  `Color` varchar(50) NOT NULL,
  `Precio` double(10,2) NOT NULL,
  `Cantidad_P` int(11) NOT NULL,
  `Categoria` varchar(50) NOT NULL,
  `Imagen` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`Id_Producto`, `Modelo`, `Marca`, `Descripcion`, `Talla`, `Color`, `Precio`, `Cantidad_P`, `Categoria`, `Imagen`) VALUES
(300030001, 'NIKEAC001', 'Nike', 'Nike Skateboard Slip On', 25.0, 'Negro/Blanco', 1890.00, 111, 'Skateboarding', 'https://scene7.zumiez.com/is/image/zumiez/product_main_medium/Nike-SB-Chron-2-Black-%26-White-Slip-On-Skate-Shoes-_343962-front-US.jpg'),
(300030002, 'NIKEAC001', 'Nike', 'Nike Skateboard Slip On', 25.5, 'Negro/Blanco', 1890.00, 111, 'Skateboarding', 'https://scene7.zumiez.com/is/image/zumiez/product_main_medium/Nike-SB-Chron-2-Black-%26-White-Slip-On-Skate-Shoes-_343962-front-US.jpg'),
(300030003, 'NIKEAC001', 'Nike', 'Nike Skateboard Slip On', 26.0, 'Negro/Blanco', 1890.00, 67, 'Skateboarding', 'https://scene7.zumiez.com/is/image/zumiez/product_main_medium/Nike-SB-Chron-2-Black-%26-White-Slip-On-Skate-Shoes-_343962-front-US.jpg'),
(300030004, 'NIKEAC001', 'Nike', 'Nike Skateboard Slip On', 26.5, 'Negro/Blanco', 1890.00, 124, 'Skateboarding', 'https://scene7.zumiez.com/is/image/zumiez/product_main_medium/Nike-SB-Chron-2-Black-%26-White-Slip-On-Skate-Shoes-_343962-front-US.jpg'),
(300030005, 'NIKEAC001', 'Nike', 'Nike Skateboard Slip On', 27.0, 'Negro/Blanco', 1890.00, 42, 'Skateboarding', 'https://scene7.zumiez.com/is/image/zumiez/product_main_medium/Nike-SB-Chron-2-Black-%26-White-Slip-On-Skate-Shoes-_343962-front-US.jpg'),
(300030006, 'NIKEAC001', 'Nike', 'Nike Skateboard Slip On', 27.5, 'Negro/Blanco', 1890.00, 85, 'Skateboarding', 'https://scene7.zumiez.com/is/image/zumiez/product_main_medium/Nike-SB-Chron-2-Black-%26-White-Slip-On-Skate-Shoes-_343962-front-US.jpg'),
(300030007, 'NIKEAC001', 'Nike', 'Nike Skateboard Slip On', 28.0, 'Negro/Blanco', 1890.00, 133, 'Skateboarding', 'https://scene7.zumiez.com/is/image/zumiez/product_main_medium/Nike-SB-Chron-2-Black-%26-White-Slip-On-Skate-Shoes-_343962-front-US.jpg'),
(300030008, 'NIKEAC001', 'Nike', 'Nike Skateboard Slip On', 28.5, 'Negro/Blanco', 1890.00, 30, 'Skateboarding', 'https://scene7.zumiez.com/is/image/zumiez/product_main_medium/Nike-SB-Chron-2-Black-%26-White-Slip-On-Skate-Shoes-_343962-front-US.jpg'),
(300030009, 'NIKEAC001', 'Nike', 'Nike Skateboard Slip On', 29.0, 'Negro/Blanco', 1890.00, 99, 'Skateboarding', 'https://scene7.zumiez.com/is/image/zumiez/product_main_medium/Nike-SB-Chron-2-Black-%26-White-Slip-On-Skate-Shoes-_343962-front-US.jpg'),
(300030010, 'NIKEAC001', 'Nike', 'Nike Skateboard Slip On', 29.5, 'Negro/Blanco', 1890.00, 201, 'Skateboarding', 'https://scene7.zumiez.com/is/image/zumiez/product_main_medium/Nike-SB-Chron-2-Black-%26-White-Slip-On-Skate-Shoes-_343962-front-US.jpg'),
(300030011, 'VANSAC001', 'VANS', 'VANS UltraRange running', 25.0, 'Negro/Blanco', 1799.00, 57, 'Deportivos', 'https://vansmx.vtexassets.com/arquivos/ids/1226965-800-auto?v=638115891130900000&width=800&height=auto&aspect=true'),
(300030012, 'VANSAC001', 'VANS', 'VANS UltraRange running', 25.5, 'Negro/Blanco', 1799.00, 112, 'Deportivos', 'https://vansmx.vtexassets.com/arquivos/ids/1226965-800-auto?v=638115891130900000&width=800&height=auto&aspect=true'),
(300030013, 'VANSAC001', 'VANS', 'VANS UltraRange running', 26.0, 'Negro/Blanco', 1799.00, 76, 'Deportivos', 'https://vansmx.vtexassets.com/arquivos/ids/1226965-800-auto?v=638115891130900000&width=800&height=auto&aspect=true'),
(300030014, 'VANSAC001', 'VANS', 'VANS UltraRange running', 26.5, 'Negro/Blanco', 1799.00, 189, 'Deportivos', 'https://vansmx.vtexassets.com/arquivos/ids/1226965-800-auto?v=638115891130900000&width=800&height=auto&aspect=true'),
(300030015, 'VANSAC001', 'VANS', 'VANS UltraRange running', 27.0, 'Negro/Blanco', 1799.00, 42, 'Deportivos', 'https://vansmx.vtexassets.com/arquivos/ids/1226965-800-auto?v=638115891130900000&width=800&height=auto&aspect=true'),
(300030016, 'VANSAC001', 'VANS', 'VANS UltraRange running', 27.5, 'Negro/Blanco', 1799.00, 205, 'Deportivos', 'https://vansmx.vtexassets.com/arquivos/ids/1226965-800-auto?v=638115891130900000&width=800&height=auto&aspect=true'),
(300030017, 'VANSAC001', 'VANS', 'VANS UltraRange running', 28.0, 'Negro/Blanco', 1799.00, 92, 'Deportivos', 'https://vansmx.vtexassets.com/arquivos/ids/1226965-800-auto?v=638115891130900000&width=800&height=auto&aspect=true'),
(300030018, 'VANSAC001', 'VANS', 'VANS UltraRange running', 28.5, 'Negro/Blanco', 1799.00, 34, 'Deportivos', 'https://vansmx.vtexassets.com/arquivos/ids/1226965-800-auto?v=638115891130900000&width=800&height=auto&aspect=true'),
(300030019, 'VANSAC001', 'VANS', 'VANS UltraRange running', 29.0, 'Negro/Blanco', 1799.00, 128, 'Deportivos', 'https://vansmx.vtexassets.com/arquivos/ids/1226965-800-auto?v=638115891130900000&width=800&height=auto&aspect=true'),
(300030020, 'DOCKAC001', 'Dockers', 'Dockers Phoenix', 25.0, 'Caramel/negro', 2199.00, 68, 'Zapato', 'https://i.pinimg.com/564x/c1/5e/68/c15e6821fb6251d2537ffe58ef53481d.jpg'),
(300030021, 'DOCKAC001', 'Dockers', 'Dockers Phoenix', 25.5, 'Caramel/negro', 2199.00, 68, 'Zapato', 'https://i.pinimg.com/564x/c1/5e/68/c15e6821fb6251d2537ffe58ef53481d.jpg'),
(300030022, 'DOCKAC001', 'Dockers', 'Dockers Phoenix', 26.0, 'Caramel/negro', 2199.00, 199, 'Zapato', 'https://i.pinimg.com/564x/c1/5e/68/c15e6821fb6251d2537ffe58ef53481d.jpg'),
(300030023, 'DOCKAC001', 'Dockers', 'Dockers Phoenix', 26.5, 'Caramel/negro', 2199.00, 55, 'Zapato', 'https://i.pinimg.com/564x/c1/5e/68/c15e6821fb6251d2537ffe58ef53481d.jpg'),
(300030024, 'DOCKAC001', 'Dockers', 'Dockers Phoenix', 27.0, 'Caramel/negro', 2199.00, 87, 'Zapato', 'https://i.pinimg.com/564x/c1/5e/68/c15e6821fb6251d2537ffe58ef53481d.jpg'),
(300030025, 'DOCKAC001', 'Dockers', 'Dockers Phoenix', 27.5, 'Caramel/negro', 2199.00, 106, 'Zapato', 'https://i.pinimg.com/564x/c1/5e/68/c15e6821fb6251d2537ffe58ef53481d.jpg'),
(300030026, 'DOCKAC001', 'Dockers', 'Dockers Phoenix', 28.0, 'Caramel/negro', 2199.00, 142, 'Zapato', 'https://i.pinimg.com/564x/c1/5e/68/c15e6821fb6251d2537ffe58ef53481d.jpg'),
(300030027, 'DOCKAC001', 'Dockers', 'Dockers Phoenix', 28.5, 'Caramel/negro', 2199.00, 74, 'Zapato', 'https://i.pinimg.com/564x/c1/5e/68/c15e6821fb6251d2537ffe58ef53481d.jpg'),
(300030028, 'DOCKAC001', 'Dockers', 'Dockers Phoenix', 29.0, 'Caramel/negro', 2199.00, 189, 'Zapato', 'https://i.pinimg.com/564x/c1/5e/68/c15e6821fb6251d2537ffe58ef53481d.jpg'),
(300033494, 'SATUAC001', 'Santucchi', 'Santucchi Lucard 08', 25.0, 'Negro', 1450.00, 50, 'Zapato', 'https://img.freepik.com/fotos-premium/zapatos-cuero-negro-diseno-moderno-brillante-sobre-fondo-blanco-creado-tecnologia-ia-generativa_67092-5980.jpg?w=2000'),
(300033495, 'SATUAC001', 'Santucchi', 'Santucchi Lucard 08', 25.5, 'Negro', 1450.00, 150, 'Zapato', 'https://img.freepik.com/fotos-premium/zapatos-cuero-negro-diseno-moderno-brillante-sobre-fondo-blanco-creado-tecnologia-ia-generativa_67092-5980.jpg?w=2000'),
(300033496, 'SATUAC001', 'Santucchi', 'Santucchi Lucard 08', 26.0, 'Negro', 1450.00, 80, 'Zapato', 'https://img.freepik.com/fotos-premium/zapatos-cuero-negro-diseno-moderno-brillante-sobre-fondo-blanco-creado-tecnologia-ia-generativa_67092-5980.jpg?w=2000'),
(300033497, 'SATUAC001', 'Santucchi', 'Santucchi Lucard 08', 26.5, 'Negro', 1450.00, 110, 'Zapato', 'https://img.freepik.com/fotos-premium/zapatos-cuero-negro-diseno-moderno-brillante-sobre-fondo-blanco-creado-tecnologia-ia-generativa_67092-5980.jpg?w=2000'),
(300033498, 'SATUAC001', 'Santucchi', 'Santucchi Lucard 08', 27.0, 'Negro', 1450.00, 40, 'Zapato', 'https://img.freepik.com/fotos-premium/zapatos-cuero-negro-diseno-moderno-brillante-sobre-fondo-blanco-creado-tecnologia-ia-generativa_67092-5980.jpg?w=2000'),
(300033499, 'SATUAC001', 'Santucchi', 'Santucchi Lucard 08', 27.5, 'Negro', 1450.00, 90, 'Zapato', 'https://img.freepik.com/fotos-premium/zapatos-cuero-negro-diseno-moderno-brillante-sobre-fondo-blanco-creado-tecnologia-ia-generativa_67092-5980.jpg?w=2000'),
(300033500, 'SATUAC001', 'Santucchi', 'Santucchi Lucard 08', 28.0, 'Negro', 1450.00, 70, 'Zapato', 'https://img.freepik.com/fotos-premium/zapatos-cuero-negro-diseno-moderno-brillante-sobre-fondo-blanco-creado-tecnologia-ia-generativa_67092-5980.jpg?w=2000'),
(300033501, 'SATUAC001', 'Santucchi', 'Santucchi Lucard 08', 28.5, 'Negro', 1450.00, 120, 'Zapato', 'https://img.freepik.com/fotos-premium/zapatos-cuero-negro-diseno-moderno-brillante-sobre-fondo-blanco-creado-tecnologia-ia-generativa_67092-5980.jpg?w=2000'),
(300033502, 'SATUAC001', 'Santucchi', 'Santucchi Lucard 08', 29.0, 'Negro', 1450.00, 200, 'Zapato', 'https://img.freepik.com/fotos-premium/zapatos-cuero-negro-diseno-moderno-brillante-sobre-fondo-blanco-creado-tecnologia-ia-generativa_67092-5980.jpg?w=2000');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `puesto_departamento`
--

CREATE TABLE `puesto_departamento` (
  `Id_PD` int(11) NOT NULL,
  `Nombre_Puesto` varchar(50) NOT NULL,
  `Salario` double(6,2) DEFAULT NULL,
  `Id_Departamento` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `puesto_departamento`
--

INSERT INTO `puesto_departamento` (`Id_PD`, `Nombre_Puesto`, `Salario`, `Id_Departamento`) VALUES
(11, 'Auxiliar Cajas', 1890.00, 10),
(12, 'Lider Cajas', 3290.00, 10),
(13, 'Auxiliar Administrativo', 1350.00, 10),
(14, 'Lider Administrativo', 2900.00, 10),
(15, 'Marketing', 1550.00, 10),
(16, 'Lider-Operador Administracion', 5750.00, 10),
(21, 'Auxiliar Almacen', 1700.00, 20),
(22, 'Sub-Lider Almacen', 2100.00, 20),
(23, ' Lider Almacen', 2850.00, 20),
(24, 'Lider-Operador Almacen ', 3890.00, 20),
(31, 'Auxiliar Inventarios', 1570.00, 30),
(32, 'Sub-Lider Inventarios', 2480.00, 30),
(33, 'Lider-Operador Inventarios', 3600.00, 30),
(41, 'Auxiliar Recursos Humanos', 1570.00, 40),
(42, 'Lider Recursos Humanos', 2480.00, 40),
(51, 'Auxiliar E-Commerce', 1650.00, 50),
(52, 'Sub-Lider E-Commerce', 2100.00, 50),
(53, 'Lider E-Commerce', 2600.00, 50),
(54, 'Lider-Operador E-Commerce', 4100.00, 50),
(61, 'Auxiliar Piso de Venta', 1690.00, 60),
(62, 'Sub-Lider Piso de Venta', 2290.00, 60),
(63, 'Lider Piso de Venta', 4350.00, 60),
(64, 'Lider-Operador Piso de Venta', 6300.00, 60);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sucursal`
--

CREATE TABLE `sucursal` (
  `Id_Sucursal` int(11) NOT NULL,
  `Nombre_Sucursal` varchar(50) NOT NULL,
  `Domicilio` varchar(150) NOT NULL,
  `Ciudad` varchar(100) NOT NULL,
  `Estado` varchar(50) NOT NULL,
  `Telefono` int(11) NOT NULL,
  `RFC` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `sucursal`
--

INSERT INTO `sucursal` (`Id_Sucursal`, `Nombre_Sucursal`, `Domicilio`, `Ciudad`, `Estado`, `Telefono`, `RFC`) VALUES
(1, 'Xstreets Plaza Patria ', 'av. Patria #9000', 'Guadalajara', 'Jaslico', 331234124, 'XTRGLD00123'),
(2, 'Xstreets Galerias', 'av. Vallarta #2300', 'Guadalajara', 'Jalisco', 123441234, 'XTRGLD00537'),
(3, 'Xstreets Avila Camacho', 'av. Avila Camacho #5000', 'Zapopan', 'Jalisco', 43455245, 'XTRZAP00087'),
(4, 'Xstreets Andares', 'av. Patria #1500', 'Zapopan', 'Jalisco', 3453455, 'XTRZAP00996'),
(5, 'Xstreets Pto. Vallarta', 'av. Blvd. Francisco Medina Ascencio #123', 'Puerto Vallarta', 'Jalisco', 3452355, 'XTRPVA00553'),
(6, 'Xstreets Residencial', 'av. Hidalgo #3434', 'Monterrey', 'Nuevo Leon', 52345523, 'XTRMTY00773'),
(7, 'Xtreets Torres Anáhua', 'av. Constituyentes #22222', 'Monterrey', 'Nuevo Leon', 67856745, 'XTRMTY00201'),
(8, 'Xtreets Polanco', 'av. La Reforma #9090', 'Polanco', 'Ciudad de Mexico', 56785678, 'XTRPLC11006'),
(9, 'Xtreets Las Lomas', 'av. Arboledas #1111', 'Las Lomas', 'Ciudad de Mexico', 45684568, 'XTRLMS330120'),
(10, 'Xtreets San nicolas', 'av. San judas #70000', 'Tijuana', 'Baja Californa', 456884568, 'XTRTIJ002233');

-- --------------------------------------------------------

--
-- Estructura para la vista `cliente_pedido`
--
DROP TABLE IF EXISTS `cliente_pedido`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `cliente_pedido`  AS SELECT `pedido_cliente`.`Id_PC` AS `Id_PC`, `cliente`.`Nombre` AS `Nombre`, `cliente`.`ApellidoP` AS `ApellidoP`, `cliente`.`ApellidoM` AS `ApellidoM`, `pedido_cliente`.`Fecha_Pedido` AS `Fecha_Pedido` FROM (`pedido_cliente` join `cliente` on(`cliente`.`Id_Cliente` = `pedido_cliente`.`Id_Cliente` and `pedido_cliente`.`Estatus` <> 'Completado'))  ;

-- --------------------------------------------------------

--
-- Estructura para la vista `pedido_com`
--
DROP TABLE IF EXISTS `pedido_com`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `pedido_com`  AS SELECT `pedido_cliente`.`Id_PC` AS `Id_PC`, `pedido_cliente`.`Fecha_Entrega` AS `Fecha_Entrega`, `pedido_cliente`.`Metodo_Entrega` AS `Metodo_Entrega`, `pedido_cliente`.`Id_Cliente` AS `Id_Cliente` FROM `pedido_cliente` WHERE `pedido_cliente`.`Estatus` = 'Completado''Completado'  ;

-- --------------------------------------------------------

--
-- Estructura para la vista `pedido_producto`
--
DROP TABLE IF EXISTS `pedido_producto`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `pedido_producto`  AS SELECT `carrito_cliente`.`Pedido` AS `Pedido`, `producto`.`Modelo` AS `Modelo`, `producto`.`Descripcion` AS `Descripcion`, `producto`.`Talla` AS `Talla`, `producto`.`Color` AS `color`, `carrito_cliente`.`Cantidad` AS `Cantidad` FROM (`carrito_cliente` join `producto` on(`producto`.`Id_Producto` = `carrito_cliente`.`Id_Producto`))  ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `carrito_cliente`
--
ALTER TABLE `carrito_cliente`
  ADD KEY `Pedido` (`Pedido`);

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`Id_Cliente`);

--
-- Indices de la tabla `departamento`
--
ALTER TABLE `departamento`
  ADD PRIMARY KEY (`Id_Departamento`);

--
-- Indices de la tabla `empleado`
--
ALTER TABLE `empleado`
  ADD PRIMARY KEY (`Id_Empleado`);

--
-- Indices de la tabla `pedido_cliente`
--
ALTER TABLE `pedido_cliente`
  ADD PRIMARY KEY (`Id_PC`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`Id_Producto`);

--
-- Indices de la tabla `puesto_departamento`
--
ALTER TABLE `puesto_departamento`
  ADD PRIMARY KEY (`Id_PD`),
  ADD KEY `Departamento` (`Id_Departamento`);

--
-- Indices de la tabla `sucursal`
--
ALTER TABLE `sucursal`
  ADD PRIMARY KEY (`Id_Sucursal`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cliente`
--
ALTER TABLE `cliente`
  MODIFY `Id_Cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10000930;

--
-- AUTO_INCREMENT de la tabla `departamento`
--
ALTER TABLE `departamento`
  MODIFY `Id_Departamento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT de la tabla `empleado`
--
ALTER TABLE `empleado`
  MODIFY `Id_Empleado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT de la tabla `pedido_cliente`
--
ALTER TABLE `pedido_cliente`
  MODIFY `Id_PC` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1000002196;

--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `Id_Producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=300033506;

--
-- AUTO_INCREMENT de la tabla `puesto_departamento`
--
ALTER TABLE `puesto_departamento`
  MODIFY `Id_PD` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT de la tabla `sucursal`
--
ALTER TABLE `sucursal`
  MODIFY `Id_Sucursal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `carrito_cliente`
--
ALTER TABLE `carrito_cliente`
  ADD CONSTRAINT `Pedido` FOREIGN KEY (`Pedido`) REFERENCES `pedido_cliente` (`Id_PC`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `puesto_departamento`
--
ALTER TABLE `puesto_departamento`
  ADD CONSTRAINT `Departamento` FOREIGN KEY (`Id_Departamento`) REFERENCES `departamento` (`Id_Departamento`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
